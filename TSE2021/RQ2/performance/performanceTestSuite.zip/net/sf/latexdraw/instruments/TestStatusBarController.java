package net.sf.latexdraw.instruments;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.TimeoutException;
import javafx.application.HostServices;
import javafx.application.Platform;
import javafx.scene.control.Hyperlink;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class TestStatusBarController extends TestLatexdrawGUI {
	@Override
	protected String getFXMLPathFromLatexdraw() {
		return "/fxml/StatusBar.fxml";
	}

	@Override
	protected Injector createInjector() {
		return new Injector() {
			@Override
			protected void configure() throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {
				bindAsEagerSingleton(StatusBarController.class);
				bindToInstance(HostServices.class, Mockito.mock(HostServices.class));
			}
		};
	}

	@Before
	public void setUp() {
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;

	@Test
	public void testClickHyperlink() {
		final Hyperlink link = find("#link");
		Platform.runLater(() -> {
			link.setText("foo");
			link.setVisible(true);
		});
		waitFXEvents.execute();
		clickOn(link);
		waitFXEvents.execute();
	}
}
