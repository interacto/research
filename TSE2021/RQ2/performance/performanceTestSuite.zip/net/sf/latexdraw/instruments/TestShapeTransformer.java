package net.sf.latexdraw.instruments;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.TimeoutException;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.mock;

public class TestShapeTransformer extends SelectionBasedTesting<ShapeTransformer> {
	Button mirrorH;
	Button mirrorV;
	Button alignBot;
	Button alignLeft;
	Button alignRight;
	Button alignTop;
	Button alignMidHoriz;
	Button alignMidVert;
	Button distribVertBot;
	Button distribVertEq;
	Button distribVertMid;
	Button distribVertTop;
	Button distribHorizEq;
	Button distribHorizLeft;
	Button distribHorizMid;
	Button distribHorizRight;
	VBox mainPane;

	final GUIVoidCommand clickAlignBot = () -> clickOn(alignBot);
	final GUIVoidCommand clickAlignTop = () -> clickOn(alignTop);
	final GUIVoidCommand clickAlignLeft = () -> clickOn(alignLeft);
	final GUIVoidCommand clickAlignRight = () -> clickOn(alignRight);
	final GUIVoidCommand clickAlignMidHoriz = () -> clickOn(alignMidHoriz);
	final GUIVoidCommand clickAlignMidVert = () -> clickOn(alignMidVert);
	final GUIVoidCommand clickMirrorH = () -> clickOn(mirrorH);
	final GUIVoidCommand clickMirrorV = () -> clickOn(mirrorV);
	final GUIVoidCommand clickDistribVertBot = () -> clickOn(distribVertBot);
	final GUIVoidCommand clickDistribVertEq = () -> clickOn(distribVertEq);
	final GUIVoidCommand clickDistribVertMid = () -> clickOn(distribVertMid);
	final GUIVoidCommand clickDistribVertTop = () -> clickOn(distribVertTop);
	final GUIVoidCommand clickDistribHorizEq = () -> clickOn(distribHorizEq);
	final GUIVoidCommand clickDistribHorizLeft = () -> clickOn(distribHorizLeft);
	final GUIVoidCommand clickDistribHorizMid = () -> clickOn(distribHorizMid);
	final GUIVoidCommand clickDistribHorizRight = () -> clickOn(distribHorizRight);

	@Override
	protected String getFXMLPathFromLatexdraw() {
		return "/fxml/Transformation.fxml";
	}

	@Override
	@Before
	public void setUp() {
		super.setUp();
		mirrorH = find("#mirrorH");
		mirrorV = find("#mirrorV");
		alignBot = find("#alignBot");
		alignLeft = find("#alignLeft");
		alignRight = find("#alignRight");
		alignTop = find("#alignTop");
		alignMidHoriz = find("#alignMidHoriz");
		alignMidVert = find("#alignMidVert");
		distribVertBot = find("#distribVertBot");
		distribVertEq = find("#distribVertEq");
		distribVertMid = find("#distribVertMid");
		distribVertTop = find("#distribVertTop");
		distribHorizEq = find("#distribHorizEq");
		distribHorizMid = find("#distribHorizMid");
		distribHorizRight = find("#distribHorizRight");
		distribHorizLeft = find("#distribHorizLeft");
		mainPane = find("#mainPane");
		ins = (ShapeTransformer) injectorFactory.call(ShapeTransformer.class);
		ins.setActivated(true);
		ins.update();
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;

	@Override
	protected Injector createInjector() {
		return new ShapePropInjector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				super.configure();
				pencil = mock(Pencil.class);
				hand = mock(Hand.class);
				bindAsEagerSingleton(ShapeTransformer.class);
				bindToInstance(Hand.class, hand);
				bindToInstance(Pencil.class, pencil);
				bindToInstance(TextSetter.class, Mockito.mock(TextSetter.class));
				bindToInstance(MetaShapeCustomiser.class, Mockito.mock(MetaShapeCustomiser.class));
			}
		};
	}

	@Test
	public void testAlignBot() {
		selectTwoShapes.execute();
		clickAlignBot.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testAlignTop() {
		selectTwoShapes.execute();
		clickAlignTop.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testAlignLeft() {
		selectTwoShapes.execute();
		clickAlignLeft.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testAlignRight() {
		selectTwoShapes.execute();
		clickAlignRight.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testAlignMidHoriz() {
		selectTwoShapes.execute();
		clickAlignMidHoriz.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testAlignMidVert() {
		selectTwoShapes.execute();
		clickAlignMidVert.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testMirrorH() {
		selectTwoShapes.execute();
		clickMirrorH.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testMirrorV() {
		selectTwoShapes.execute();
		clickMirrorV.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testDistribVertBot() {
		selectThreeShapes.execute();
		clickDistribVertBot.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testDistribVertEq() {
		selectThreeShapes.execute();
		clickDistribVertEq.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testDistribVertMid() {
		selectThreeShapes.execute();
		clickDistribVertMid.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testDistribVertTop() {
		selectThreeShapes.execute();
		clickDistribVertTop.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testDistribHorizEq() {
		selectThreeShapes.execute();
		clickDistribHorizEq.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testDistribHorizLeft() {
		selectThreeShapes.execute();
		clickDistribHorizLeft.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testDistribHorizMid() {
		selectThreeShapes.execute();
		clickDistribHorizMid.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testDistribHorizRight() {
		selectThreeShapes.execute();
		clickDistribHorizRight.execute();
		waitFXEvents.execute();
	}
}
