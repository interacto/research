package net.sf.latexdraw.instruments;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.TimeoutException;
import javafx.application.Platform;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import net.sf.latexdraw.models.ShapeFactory;
import net.sf.latexdraw.models.interfaces.shape.IPoint;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.testfx.util.WaitForAsyncUtils;

import static org.mockito.Mockito.when;

public class TestBorder extends BaseTestCanvas  {
	Border border;
	final double txDown = 50;
	final double tyDown = 200d;
	final GUIVoidCommand rotateDown = () -> drag(border.rotHandler).dropBy(txDown, tyDown);

	@Override
	protected Injector createInjector() {
		return new ShapePropInjector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				super.configure();
				bindAsEagerSingleton(Border.class);
				bindToInstance(CanvasController.class, Mockito.mock(CanvasController.class));
				bindAsEagerSingleton(FacadeCanvasController.class);
				bindAsEagerSingleton(Hand.class);
				bindToInstance(Pencil.class, Mockito.mock(Pencil.class));
				bindAsEagerSingleton(MetaShapeCustomiser.class);
				bindToInstance(ShapeTextCustomiser.class, Mockito.mock(ShapeTextCustomiser.class));
				bindToInstance(ShapePlotCustomiser.class, Mockito.mock(ShapePlotCustomiser.class));
				bindToInstance(ShapeCoordDimCustomiser.class, Mockito.mock(ShapeCoordDimCustomiser.class));
				bindToInstance(ShapeAxesCustomiser.class, Mockito.mock(ShapeAxesCustomiser.class));
				bindToInstance(ShapeDoubleBorderCustomiser.class, Mockito.mock(ShapeDoubleBorderCustomiser.class));
				bindToInstance(ShapeFreeHandCustomiser.class, Mockito.mock(ShapeFreeHandCustomiser.class));
				bindToInstance(ShapeShadowCustomiser.class, Mockito.mock(ShapeShadowCustomiser.class));
				bindToInstance(ShapeFillingCustomiser.class, Mockito.mock(ShapeFillingCustomiser.class));
				bindToInstance(ShapeTransformer.class, Mockito.mock(ShapeTransformer.class));
				bindToInstance(ShapeGrouper.class, Mockito.mock(ShapeGrouper.class));
				bindToInstance(ShapeGridCustomiser.class, Mockito.mock(ShapeGridCustomiser.class));
				bindToInstance(ShapePositioner.class, Mockito.mock(ShapePositioner.class));
				bindToInstance(ShapeRotationCustomiser.class, Mockito.mock(ShapeRotationCustomiser.class));
				bindToInstance(ShapeArrowCustomiser.class, Mockito.mock(ShapeArrowCustomiser.class));
				bindToInstance(ShapeDotCustomiser.class, Mockito.mock(ShapeDotCustomiser.class));
				bindToInstance(ShapeStdGridCustomiser.class, Mockito.mock(ShapeStdGridCustomiser.class));
				bindToInstance(ShapeBorderCustomiser.class, Mockito.mock(ShapeBorderCustomiser.class));
				bindToInstance(ShapeArcCustomiser.class, Mockito.mock(ShapeArcCustomiser.class));
				bindAsEagerSingleton(TextSetter.class);
			}
		};
	}

	@Override
	@Before
	public void setUp() {
		super.setUp();
		hand.setActivated(true);
		when(pencil.isActivated()).thenReturn(false);
		border = (Border) injectorFactory.call(Border.class);
		WaitForAsyncUtils.waitForFxEvents();
		((Arc) border.rotHandler.getChildren().get(0)).setFill(Color.WHITE);
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;

	@Test
	public void testMovePtHandlerMovePt() {
		new CompositeGUIVoidCommand(addLines, waitFXEvents, selectAllShapes, waitFXEvents).execute();
		final IPoint point = ShapeFactory.INST.createPoint(addedPolyline.getPtAt(1));
		point.translate(100d, 20d);
		drag(border.mvPtHandlers.get(1)).dropBy(100d, 20d);
		waitFXEvents.execute();
	}

	@Test
	public void testMovePtHandlerMovePtWithRotation() {
		new CompositeGUIVoidCommand(addLines, waitFXEvents, selectAllShapes, waitFXEvents).execute();
		addedPolyline.setRotationAngle(Math.PI);
		waitFXEvents.execute();
		final IPoint point = ShapeFactory.INST.createPoint(addedPolyline.getPtAt(1));
		point.translate(100d, 20d);
		drag(border.mvPtHandlers.get(1)).dropBy(100d, 20d);
		waitFXEvents.execute();
	}

	@Test
	public void testMoveCtrl1PtHandlerMovePt() {
		new CompositeGUIVoidCommand(addBezier, waitFXEvents, selectAllShapes, waitFXEvents).execute();
		final IPoint point = ShapeFactory.INST.createPoint(addedBezier.getFirstCtrlPtAt(1));
		point.translate(100d, 20d);
		drag(border.ctrlPt1Handlers.get(1)).dropBy(100d, 20d);
		waitFXEvents.execute();
	}

	@Test
	public void testMoveCtrl2PtHandlerMovePt() {
		new CompositeGUIVoidCommand(addBezier, waitFXEvents, selectAllShapes, waitFXEvents).execute();
		final IPoint point = ShapeFactory.INST.createPoint(addedBezier.getSecondCtrlPtAt(2));
		point.translate(100d, 20d);
		drag(border.ctrlPt2Handlers.get(2)).dropBy(100d, 20d);
		waitFXEvents.execute();
	}

	@Test
	public void testRotateRectangle() {
		new CompositeGUIVoidCommand(addRec, waitFXEvents, selectAllShapes).execute();
		new CompositeGUIVoidCommand(rotateDown, waitFXEvents).execute();
	}

	@Test
	public void testRotateTwoRectangles() {
		new CompositeGUIVoidCommand(addRec, addRec, waitFXEvents).execute();
		Platform.runLater(() -> canvas.getDrawing().getShapeAt(1).translate(150, 60));
		selectAllShapes.execute();
		new CompositeGUIVoidCommand(rotateDown, waitFXEvents).execute();
	}

	@Test
	public void testArcStartHandler() {
		new CompositeGUIVoidCommand(addArc, waitFXEvents, selectAllShapes, waitFXEvents).execute();
		final IPoint gc = addedArc.getGravityCentre();
		final IPoint point = ShapeFactory.INST.createPoint(addedArc.getStartPoint());
		final IPoint newpoint = point.rotatePoint(gc, -Math.PI / 4d);
		drag(border.arcHandlerStart).dropBy(newpoint.getX() - point.getX(), newpoint.getY() - point.getY());
		waitFXEvents.execute();
	}

	@Test
	public void testArcEndHandler() {
		new CompositeGUIVoidCommand(addArc, waitFXEvents, selectAllShapes, waitFXEvents).execute();
		final IPoint gc = addedArc.getGravityCentre();
		final IPoint point = ShapeFactory.INST.createPoint(addedArc.getEndPoint());
		final IPoint newpoint = point.rotatePoint(gc, Math.PI / 3d);
		drag(border.arcHandlerEnd).dropBy(newpoint.getX() - point.getX(), newpoint.getY() - point.getY());
		waitFXEvents.execute();
	}

	@Test
	public void testScaleWRectangle() {
		new CompositeGUIVoidCommand(addRec, waitFXEvents, selectAllShapes).execute();
		final IPoint tl = addedRec.getTopLeftPoint();
		tl.translate(50d, 0d);
		drag(border.scaleHandlers.get(3)).dropBy(50d, 10d);
		waitFXEvents.execute();
	}

	@Test
	public void testScaleERectangle() {
		new CompositeGUIVoidCommand(addRec, waitFXEvents, selectAllShapes).execute();
		final IPoint tr = addedRec.getTopRightPoint();
		tr.translate(50d, 0d);
		drag(border.scaleHandlers.get(4)).dropBy(50d, 10d);
		waitFXEvents.execute();
	}

	@Test
	public void testScaleNRectangle() {
		new CompositeGUIVoidCommand(addRec, waitFXEvents, selectAllShapes).execute();
		final IPoint tr = addedRec.getTopRightPoint();
		tr.translate(0d, -20d);
		drag(border.scaleHandlers.get(1)).dropBy(30d, -20d);
		waitFXEvents.execute();
	}

	@Test
	public void testScaleSRectangle() {
		new CompositeGUIVoidCommand(addRec, waitFXEvents, selectAllShapes).execute();
		final IPoint bl = addedRec.getBottomLeftPoint();
		bl.translate(0d, 50d);
		drag(border.scaleHandlers.get(6)).dropBy(30d, 50d);
		waitFXEvents.execute();
	}

	@Test
	public void testScaleNORectangle() {
		new CompositeGUIVoidCommand(addRec, waitFXEvents, selectAllShapes).execute();
		final IPoint tl = addedRec.getTopLeftPoint();
		tl.translate(50d, 70d);
		drag(border.scaleHandlers.get(0)).dropBy(50d, 70d);
		waitFXEvents.execute();
	}

	@Test
	public void testScaleNERectangle() {
		new CompositeGUIVoidCommand(addRec, waitFXEvents, selectAllShapes).execute();
		final IPoint tr = addedRec.getTopRightPoint();
		tr.translate(50d, -40d);
		drag(border.scaleHandlers.get(2)).dropBy(50d, -40d);
		waitFXEvents.execute();
	}

	@Test
	public void testScaleSORectangle() {
		new CompositeGUIVoidCommand(addRec, waitFXEvents, selectAllShapes).execute();
		final IPoint bl = addedRec.getBottomLeftPoint();
		bl.translate(50d, 70d);
		drag(border.scaleHandlers.get(5)).dropBy(50d, 70d);
		waitFXEvents.execute();
	}

	@Test
	public void testScaleSERectangle() {
		new CompositeGUIVoidCommand(addRec, waitFXEvents, selectAllShapes).execute();
		final IPoint br = addedRec.getBottomRightPoint();
		br.translate(-55d, 45d);
		drag(border.scaleHandlers.get(7)).dropBy(-55d, 45d);
		waitFXEvents.execute();
	}
}
