package net.sf.latexdraw;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public interface HelperTest {
	static void setFinalStaticFieldValue(final Field field, final Object value) throws IllegalAccessException, NoSuchFieldException {
		field.setAccessible(true);
		final Field modField = Field.class.getDeclaredField("modifiers");
		modField.setAccessible(true);
		modField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
		field.set(null, value);
	}
}
