package net.sf.latexdraw.instruments;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.concurrent.TimeoutException;
import javafx.collections.FXCollections;
import javafx.scene.control.ProgressBar;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import net.sf.latexdraw.HelperTest;
import net.sf.latexdraw.LaTeXDraw;
import net.sf.latexdraw.models.ShapeFactory;
import net.sf.latexdraw.models.interfaces.shape.IDrawing;
import net.sf.latexdraw.util.Injector;
import net.sf.latexdraw.view.jfx.Canvas;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.mockito.Mockito;

public class TestFileLoaderSaver extends TestLatexdrawGUI {
	FileLoaderSaver loader;
	FileChooser chooser;
	@Rule public TemporaryFolder tmp = new TemporaryFolder();

	@Override
	protected String getFXMLPathFromLatexdraw() {
		return "/fxml/OpenSave.fxml";
	}

	@BeforeClass
	public static void beforeAll() throws NoSuchFieldException, IllegalAccessException {
		HelperTest.setFinalStaticFieldValue(LaTeXDraw.class.getDeclaredField("instance"), Mockito.mock(LaTeXDraw.class));
	}

	@AfterClass
	public static void afterAll() throws NoSuchFieldException, IllegalAccessException {
		HelperTest.setFinalStaticFieldValue(LaTeXDraw.class.getDeclaredField("instance"), null);
	}

	@Override
	protected Injector createInjector() {
		return new Injector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				bindToInstance(PreferencesSetter.class, Mockito.mock(PreferencesSetter.class));
				bindToInstance(StatusBarController.class, Mockito.mock(StatusBarController.class));
				bindToInstance(IDrawing.class, ShapeFactory.INST.createDrawing());
				bindToInstance(Canvas.class, Mockito.mock(Canvas.class));
				bindAsEagerSingleton(FileLoaderSaver.class);
			}
		};
	}

	@Override
	public void start(final Stage aStage) {
		Mockito.when(LaTeXDraw.getInstance().getMainStage()).thenReturn(aStage);
		super.start(aStage);
	}

	@Before
	public void setUp() throws NoSuchFieldException, IllegalAccessException, IOException {
		Mockito.when(LaTeXDraw.getInstance().getInjector()).thenReturn(injector);
		loader = injector.getInstance(FileLoaderSaver.class);

		chooser = Mockito.mock(FileChooser.class);
		Mockito.when(chooser.getExtensionFilters()).thenReturn(FXCollections.observableArrayList());
		final Field field = FileLoaderSaver.class.getDeclaredField("fileChooser");
		field.setAccessible(true);
		field.set(loader, chooser);
		loader.setCurrentFile(tmp.newFile());

		Mockito.when(injector.getInstance(StatusBarController.class).getProgressBar()).thenReturn(new ProgressBar());
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;

	@Test
	public void testNewMenu() {
		Mockito.when(LaTeXDraw.getInstance().isModified()).thenReturn(false);
		clickOn("#fileMenu").clickOn("#newMenu");
		waitFXEvents.execute();
	}

	@Test
	public void testSaveMenu() {
		Mockito.when(LaTeXDraw.getInstance().isModified()).thenReturn(true);
		clickOn("#fileMenu").clickOn("#saveMenu");
		waitFXEvents.execute();
	}

	@Test
	public void testSaveAsMenu() throws IOException {
		Mockito.when(chooser.showSaveDialog(Mockito.any())).thenReturn(tmp.newFile());
		Mockito.when(LaTeXDraw.getInstance().isModified()).thenReturn(true);
		clickOn("#fileMenu").clickOn("#saveAsMenu");
		waitFXEvents.execute();
	}

	@Test
	public void testLoadMenu() {
		final File file = new File(getClass().getResource("/test.svg").getFile());
		loader.setCurrentFile(file);
		Mockito.when(LaTeXDraw.getInstance().isModified()).thenReturn(false);
		clickOn("#fileMenu").clickOn("#loadMenu");
		waitFXEvents.execute();
	}

	@Test
	public void testRecentMenu() {
		loader.updateRecentMenuItems(Collections.singletonList(getClass().getResource("/test.svg").getFile()));
		Mockito.when(LaTeXDraw.getInstance().isModified()).thenReturn(false);
		clickOn("#fileMenu").clickOn("#recentFilesMenu").clickOn("#recent0");
		waitFXEvents.execute();
	}
}
