package net.sf.latexdraw.instruments;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.TimeoutException;
import javafx.scene.Node;
import javafx.stage.Stage;
import net.sf.latexdraw.badaboom.BadaboomCollector;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.fail;

public class TestExceptionManager extends TestLatexdrawGUI {
	ExceptionsManager manager;

	@Override
	protected Injector createInjector() {
		return new Injector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				bindAsEagerSingleton(ExceptionsManager.class);
			}
		};
	}

	@Override
	protected String getFXMLPathFromLatexdraw() {
		return "/fxml/Error.fxml";
	}

	@Before
	public void setUp() {
		manager = injector.getInstance(ExceptionsManager.class);
		try {
			final Field field = ExceptionsManager.class.getDeclaredField("stageEx");
			field.setAccessible(true);
			field.set(manager, Mockito.mock(Stage.class));
		}catch(final IllegalAccessException | NoSuchFieldException ex) {
			fail(ex.getMessage());
		}
		time = System.currentTimeMillis();
	}

	long time;

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
		BadaboomCollector.INSTANCE.clear();
		BadaboomCollector.INSTANCE.removeHandler(manager);
	}

	private Node getButton() {
		return find("#exceptionB");
	}

	@Test
	public void testClickShowErrorStage() {
		BadaboomCollector.INSTANCE.add(new IllegalArgumentException());
		clickOn(getButton());
		waitFXEvents.execute();
	}
}
