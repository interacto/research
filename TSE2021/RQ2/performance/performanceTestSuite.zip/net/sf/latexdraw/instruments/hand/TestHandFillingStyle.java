package net.sf.latexdraw.instruments.hand;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.concurrent.TimeoutException;
import net.sf.latexdraw.instruments.CompositeGUIVoidCommand;
import net.sf.latexdraw.instruments.Hand;
import net.sf.latexdraw.instruments.MetaShapeCustomiser;
import net.sf.latexdraw.instruments.Pencil;
import net.sf.latexdraw.instruments.ShapeFillingCustomiser;
import net.sf.latexdraw.instruments.ShapePropInjector;
import net.sf.latexdraw.instruments.TestFillingStyleGUI;
import net.sf.latexdraw.instruments.TextSetter;
import net.sf.latexdraw.models.interfaces.shape.FillingStyle;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class TestHandFillingStyle extends TestFillingStyleGUI {
	@Override
	protected Injector createInjector() {
		return new ShapePropInjector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				super.configure();
				pencil = mock(Pencil.class);
				bindAsEagerSingleton(ShapeFillingCustomiser.class);
				bindAsEagerSingleton(Hand.class);
				bindToInstance(MetaShapeCustomiser.class, mock(MetaShapeCustomiser.class));
				bindToInstance(TextSetter.class, mock(TextSetter.class));
				bindToInstance(Pencil.class, pencil);
			}
		};
	}

	@Override
	@Before
	public void setUp() {
		super.setUp();
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;


	@Test
	public void testNotFillingWidgetsNotEnabledHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddRec, selectGradStyle, updateIns).execute();
	}

	@Test
	public void testNotGradWidgetsNotEnabledHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddRec, selectHatchingsStyle, updateIns).execute();
	}

	@Test
	public void testNotHatchWidgetsNotEnabledHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddRec, selectGradStyle, updateIns).execute();
	}

	@Test
	public void testSelectFillingPlainHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, updateIns).execute();
		selectStyle.execute(FillingStyle.PLAIN);
		waitFXEvents.execute();
	}

	@Test
	public void testPickFillingColourHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, selectPlainStyle, updateIns).execute();
		pickfillCol.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testPickHatchingsColourHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, selectHatchingsStyle, updateIns).execute();
		pickhatchCol.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testPickGradStartColourHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, selectGradStyle, updateIns).execute();
		pickgradStartCol.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testPickGradEndColourHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, selectGradStyle, updateIns).execute();
		pickgradEndCol.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testIncrementGradMidHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, updateIns, selectGradStyle), gradMidPtField,
			incrementgradMidPt, Arrays.asList(
			() ->  drawing.getSelection().getShapeAt(1).getGradMidPt(),
			() ->  drawing.getSelection().getShapeAt(2).getGradMidPt()));
	}

	@Test
	public void testIncrementGradAngleHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, updateIns, selectGradStyle), gradAngleField,
			incrementgradAngle, Arrays.asList(
			() ->  Math.toDegrees(drawing.getSelection().getShapeAt(1).getGradAngle()),
			() ->  Math.toDegrees(drawing.getSelection().getShapeAt(2).getGradAngle())));
	}

	@Test
	public void testIncrementHatchAngleHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, updateIns, selectHatchingsStyle), hatchAngleField,
			incrementhatchAngle, Arrays.asList(
			() ->  Math.toDegrees(drawing.getSelection().getShapeAt(1).getHatchingsAngle()),
			() ->  Math.toDegrees(drawing.getSelection().getShapeAt(2).getHatchingsAngle())));
	}

	@Test
	public void testIncrementHatchWidthHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, updateIns, selectHatchingsStyle), hatchWidthField,
			incrementhatchWidth, Arrays.asList(
			() ->  drawing.getSelection().getShapeAt(1).getHatchingsWidth(),
			() ->  drawing.getSelection().getShapeAt(2).getHatchingsWidth()));
	}

	@Test
	public void testIncrementHatchSepHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddRec, selectionAddBezier, updateIns, selectHatchingsStyle), hatchSepField,
			incrementhatchSep, Arrays.asList(
			() ->  drawing.getSelection().getShapeAt(1).getHatchingsSep(),
			() ->  drawing.getSelection().getShapeAt(2).getHatchingsSep()));
	}
}
