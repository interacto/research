package net.sf.latexdraw.data;

public interface ValuesGenerator {
	double[] doubleValues = {-0.00001, -1.34, -83.12, 0d, 0.00001, 1.34, 83.12};
	float[] floatValues = {-10.23f, -0.001f, 0f, 0.00001f, 1.34f, 83.12f};
}
