package net.sf.latexdraw.instruments.hand;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.concurrent.TimeoutException;
import javafx.application.Platform;
import net.sf.latexdraw.instruments.CompositeGUIVoidCommand;
import net.sf.latexdraw.instruments.Hand;
import net.sf.latexdraw.instruments.MetaShapeCustomiser;
import net.sf.latexdraw.instruments.Pencil;
import net.sf.latexdraw.instruments.ShapePlotCustomiser;
import net.sf.latexdraw.instruments.ShapePropInjector;
import net.sf.latexdraw.instruments.TestPlotStyleGUI;
import net.sf.latexdraw.instruments.TextSetter;
import net.sf.latexdraw.models.interfaces.shape.IPlot;
import net.sf.latexdraw.models.interfaces.shape.PlotStyle;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.testfx.util.WaitForAsyncUtils;

import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class TestHandPlotStyle extends TestPlotStyleGUI {
	@Override
	protected Injector createInjector() {
		return new ShapePropInjector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				super.configure();
				pencil = mock(Pencil.class);
				bindAsEagerSingleton(ShapePlotCustomiser.class);
				bindAsEagerSingleton(Hand.class);
				bindToInstance(MetaShapeCustomiser.class, mock(MetaShapeCustomiser.class));
				bindToInstance(TextSetter.class, mock(TextSetter.class));
				bindToInstance(Pencil.class, pencil);
			}
		};
	}

	@Override
	@Before
	public void setUp() {
		super.setUp();
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;


	@Test
	public void testSelectDOTSStyleHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns).execute();
		selectplotStyleCB.execute(PlotStyle.DOTS);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectCCURVEStyleHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns).execute();
		selectplotStyleCB.execute(PlotStyle.CCURVE);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectPOLYGONStyleHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns).execute();
		selectplotStyleCB.execute(PlotStyle.POLYGON);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectECURVEStyleHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns).execute();
		selectplotStyleCB.execute(PlotStyle.ECURVE);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectCURVEStyleHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns).execute();
		selectplotStyleCB.execute(PlotStyle.ECURVE);
		selectplotStyleCB.execute(PlotStyle.CURVE);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLINEStyleHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns).execute();
		selectplotStyleCB.execute(PlotStyle.LINE);
		waitFXEvents.execute();
	}

	@Test
	public void testIncrementnbPtsSpinnerHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns), nbPtsSpinner,
			incrementnbPtsSpinner, Arrays.asList(
				() -> ((IPlot)drawing.getSelection().getShapeAt(1)).getNbPlottedPoints(),
				() -> ((IPlot)drawing.getSelection().getShapeAt(2)).getNbPlottedPoints()
			));
	}

	@Test
	public void testIncrementminXSpinnerHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns), minXSpinner,
			incrementminXSpinner, Arrays.asList(
			() ->  ((IPlot) drawing.getSelection().getShapeAt(1)).getPlotMinX(),
			() ->  ((IPlot) drawing.getSelection().getShapeAt(2)).getPlotMinX()));
	}

	@Test
	public void testIncrementmaxXSpinnerHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns), maxXSpinner,
			incrementmaxXSpinner, Arrays.asList(
			() ->  ((IPlot) drawing.getSelection().getShapeAt(1)).getPlotMaxX(),
			() ->  ((IPlot) drawing.getSelection().getShapeAt(2)).getPlotMaxX()));
	}

	@Test
	public void testIncrementxScaleSpinnerHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns), xScaleSpinner,
			incrementxScaleSpinner, Arrays.asList(
			() ->  ((IPlot) drawing.getSelection().getShapeAt(1)).getXScale(),
			() ->  ((IPlot) drawing.getSelection().getShapeAt(2)).getXScale()));
	}

	@Test
	public void testIncrementyScaleSpinnerHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns), yScaleSpinner,
			incrementyScaleSpinner, Arrays.asList(
			() ->  ((IPlot) drawing.getSelection().getShapeAt(1)).getYScale(),
			() ->  ((IPlot) drawing.getSelection().getShapeAt(2)).getYScale()));
	}

	@Test
	public void testSelectpolarCBHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddPlot, selectionAddPlot, updateIns).execute();
		clickpolarCB.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testCrashInvalidFunctionValueMinX() {
		new CompositeGUIVoidCommand(activateHand, selectionAddPlot, updateIns).execute();
		Platform.runLater(() -> ((IPlot) drawing.getSelection().getShapeAt(0)).setPlotEquation("x log"));
		WaitForAsyncUtils.waitForFxEvents();
		minXSpinner.getEditor().setText("0");
		minXSpinner.getEditor().commitValue();
		WaitForAsyncUtils.waitForFxEvents();
	}

	@Test
	public void testCrashInvalidFunctionValueMaxX() {
		new CompositeGUIVoidCommand(activateHand, selectionAddPlot, updateIns).execute();
		Platform.runLater(() -> ((IPlot) drawing.getSelection().getShapeAt(0)).setPlotEquation("2 x div"));
		WaitForAsyncUtils.waitForFxEvents();
		minXSpinner.getEditor().setText("-1");
		minXSpinner.getEditor().commitValue();
		WaitForAsyncUtils.waitForFxEvents();
		maxXSpinner.getEditor().setText("0");
		maxXSpinner.getEditor().commitValue();
		WaitForAsyncUtils.waitForFxEvents();
	}

	@Test
	public void testCrashInvalidFunctionPolarToCart() {
		new CompositeGUIVoidCommand(activateHand, selectionAddPlot, clickpolarCB, updateIns).execute();
		Platform.runLater(() -> ((IPlot) drawing.getSelection().getShapeAt(0)).setPlotEquation("2 x div"));
		WaitForAsyncUtils.waitForFxEvents();
		minXSpinner.getEditor().setText("-1");
		minXSpinner.getEditor().commitValue();
		WaitForAsyncUtils.waitForFxEvents();
		maxXSpinner.getEditor().setText("0");
		maxXSpinner.getEditor().commitValue();
		WaitForAsyncUtils.waitForFxEvents();
		clickpolarCB.execute();
		WaitForAsyncUtils.waitForFxEvents();
	}
}
