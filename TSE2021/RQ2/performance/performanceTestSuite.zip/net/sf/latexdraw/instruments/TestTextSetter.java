package net.sf.latexdraw.instruments;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.TimeoutException;
import javafx.application.Platform;
import javafx.geometry.Point2D;
import javafx.scene.control.Spinner;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.testfx.util.WaitForAsyncUtils;

import static org.mockito.Mockito.when;

public class TestTextSetter extends BaseTestCanvas {
	TextSetter setter;
	ShapePlotCustomiser plot;

	@Override
	protected Injector createInjector() {
		return new ShapePropInjector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				super.configure();
				bindToInstance(Border.class, Mockito.mock(Border.class));
				bindToInstance(CanvasController.class, Mockito.mock(CanvasController.class));
				bindAsEagerSingleton(FacadeCanvasController.class);
				bindAsEagerSingleton(Pencil.class);
				bindToInstance(Hand.class, Mockito.mock(Hand.class));
				bindToInstance(MetaShapeCustomiser.class, Mockito.mock(MetaShapeCustomiser.class));
				bindAsEagerSingleton(TextSetter.class);
				bindToInstance(ShapeTextCustomiser.class, Mockito.mock(ShapeTextCustomiser.class));
				bindToInstance(ShapePlotCustomiser.class, Mockito.mock(ShapePlotCustomiser.class));
			}
		};
	}

	@Override
	@Before
	public void setUp() {
		super.setUp();
		setter = (TextSetter) injectorFactory.call(TextSetter.class);
		plot = (ShapePlotCustomiser) injectorFactory.call(ShapePlotCustomiser.class);
		plot.maxXSpinner = Mockito.mock(Spinner.class);
		plot.minXSpinner = Mockito.mock(Spinner.class);
		plot.nbPtsSpinner = Mockito.mock(Spinner.class);
		when(plot.maxXSpinner.getValue()).thenReturn(10d);
		when(plot.minXSpinner.getValue()).thenReturn(0d);
		when(plot.nbPtsSpinner.getValue()).thenReturn(10);
		pencil.setActivated(true);
		canvas.getMagneticGrid().setMagnetic(false);
		Platform.runLater(() -> setter.initialize(null, null));
		WaitForAsyncUtils.waitForFxEvents(100);
		canvas.toFront();
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;

	@Test
	public void testNotActivated() {
		pencil.setCurrentChoice(EditionChoice.DOT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY);
		waitFXEvents.execute();
	}

	@Test
	public void testShowTextTextField() {
		pencil.setCurrentChoice(EditionChoice.TEXT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY);
		waitFXEvents.execute();
	}

	@Test
	public void testShowPlotTextField() {
		pencil.setCurrentChoice(EditionChoice.PLOT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY);
		waitFXEvents.execute();
	}

	@Test
	public void testTypeTextFieldOKAddShape() {
		pencil.setCurrentChoice(EditionChoice.TEXT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY).sleep(10).write("foo bar").type(KeyCode.ENTER);
		waitFXEvents.execute();
	}

	@Test
	public void testTypeEqFieldOKAddShape() {
		pencil.setCurrentChoice(EditionChoice.PLOT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY).sleep(10).write("x 2 mul").type(KeyCode.ENTER);
		waitFXEvents.execute();
	}

	@Test
	public void testHideTextFieldOnOK() {
		pencil.setCurrentChoice(EditionChoice.TEXT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY).sleep(10).write("foo bar").type(KeyCode.ENTER);
		waitFXEvents.execute();
	}

	@Test
	public void testHidePlotFieldOnOK() {
		pencil.setCurrentChoice(EditionChoice.PLOT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY).sleep(10).write("x 2 mul").type(KeyCode.ENTER);
		waitFXEvents.execute();
	}

	@Test
	public void testNotHidePlotFieldOnKO() {
		pencil.setCurrentChoice(EditionChoice.PLOT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY).sleep(10).write("not a valid formula").type(KeyCode.ENTER);
		waitFXEvents.execute();
	}

	@Test
	public void testNotHideTextFieldOnEmptyField() {
		pencil.setCurrentChoice(EditionChoice.TEXT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY).sleep(10).write("foo").eraseText(3).type(KeyCode.ENTER);
		waitFXEvents.execute();
	}

	@Test
	public void testNotHidePlotFieldOnEmptyField() {
		pencil.setCurrentChoice(EditionChoice.PLOT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY).sleep(10).write("x").eraseText(1).type(KeyCode.ENTER);
		waitFXEvents.execute();
	}

	@Test
	public void testEscapeText() {
		pencil.setCurrentChoice(EditionChoice.TEXT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY).sleep(10).write("foo").type(KeyCode.ESCAPE);
		waitFXEvents.execute();
	}

	@Test
	public void testEscapePlot() {
		pencil.setCurrentChoice(EditionChoice.PLOT);
		final Point2D pos = point(canvas).query();
		moveTo(pos).clickOn(MouseButton.PRIMARY).sleep(10).write("x").type(KeyCode.ESCAPE);
		waitFXEvents.execute();
	}
}
