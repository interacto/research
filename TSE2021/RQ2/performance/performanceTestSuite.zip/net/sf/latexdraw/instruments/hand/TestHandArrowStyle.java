package net.sf.latexdraw.instruments.hand;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.TimeoutException;
import net.sf.latexdraw.instruments.CompositeGUIVoidCommand;
import net.sf.latexdraw.instruments.Hand;
import net.sf.latexdraw.instruments.MetaShapeCustomiser;
import net.sf.latexdraw.instruments.Pencil;
import net.sf.latexdraw.instruments.ShapeArrowCustomiser;
import net.sf.latexdraw.instruments.ShapePropInjector;
import net.sf.latexdraw.instruments.TestArrowStyleGUI;
import net.sf.latexdraw.instruments.TextSetter;
import net.sf.latexdraw.models.interfaces.shape.ArrowStyle;
import net.sf.latexdraw.models.interfaces.shape.IArrowableSingleShape;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class TestHandArrowStyle extends TestArrowStyleGUI {
	@Override
	protected Injector createInjector() {
		return new ShapePropInjector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				super.configure();
				pencil = mock(Pencil.class);
				bindAsEagerSingleton(ShapeArrowCustomiser.class);
				bindAsEagerSingleton(Hand.class);
				bindToInstance(MetaShapeCustomiser.class, mock(MetaShapeCustomiser.class));
				bindToInstance(TextSetter.class, mock(TextSetter.class));
				bindToInstance(Pencil.class, pencil);
			}
		};
	}

	@Override
	@Before
	public void setUp() {
		super.setUp();
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;

	@Test
	public void testSelectLeftArrowStyleHand() {
		new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.BAR_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleHand() {
		new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.ROUND_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testIncrementtbarsizeNumHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleRBrack), tbarsizeNum,
			incrementtbarsizeNum, Collections.emptyList());
	}

	@Test
	public void testIncrementtbarsizeDimHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleRBrack), tbarsizeDim,
			incrementtbarsizeDim, Collections.emptyList());
	}

	@Test
	public void testIncrementdotSizeNumHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleDot), dotSizeNum,
			incrementdotSizeNum, Arrays.asList(
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(0)).getDotSizeNum(),
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(1)).getDotSizeNum()));
	}

	@Test
	public void testIncrementdotSizeDimHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleDot), dotSizeDim,
			incrementdotSizeDim, Arrays.asList(
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(0)).getDotSizeDim(),
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(1)).getDotSizeDim()));
	}

	@Test
	public void testIncrementrbracketNumHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleRBrack), rbracketNum,
			incrementrbracketNum, Arrays.asList(
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(0)).getRBracketNum(),
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(1)).getRBracketNum()));
	}

	@Test
	public void testIncrementbracketNumHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleSBrack), bracketNum,
			incrementbracketNum, Arrays.asList(
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(0)).getBracketNum(),
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(1)).getBracketNum()));
	}

	@Test
	public void testIncrementarrowLengthHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleArrow), arrowLength,
			incrementarrowLength, Arrays.asList(
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(0)).getArrowLength(),
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(1)).getArrowLength()));
	}

	@Test
	public void testIncrementarrowInsetHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleArrow), arrowInset,
			incrementarrowInset, Arrays.asList(
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(0)).getArrowInset(),
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(1)).getArrowInset()));
	}

	@Test
	public void testIncrementarrowSizeNumHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleArrow), arrowSizeNum,
			incrementarrowSizeNum, Arrays.asList(
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(0)).getArrowSizeNum(),
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(1)).getArrowSizeNum()));
	}

	@Test
	public void testIncrementarrowSizeDimHand() {
		doTestSpinner(new CompositeGUIVoidCommand(selectionAddBezier, selectionAddBezier, activateHand, updateIns, selectArrowStyleArrow), arrowSizeDim,
			incrementarrowSizeDim, Arrays.asList(
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(0)).getArrowSizeDim(),
			() ->  ((IArrowableSingleShape) drawing.getSelection().getShapeAt(1)).getArrowSizeDim()));
	}
}
