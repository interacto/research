package net.sf.latexdraw.instruments.hand;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.concurrent.TimeoutException;
import net.sf.latexdraw.instruments.CompositeGUIVoidCommand;
import net.sf.latexdraw.instruments.Hand;
import net.sf.latexdraw.instruments.MetaShapeCustomiser;
import net.sf.latexdraw.instruments.Pencil;
import net.sf.latexdraw.instruments.ShapeGridCustomiser;
import net.sf.latexdraw.instruments.ShapePropInjector;
import net.sf.latexdraw.instruments.TestGridStyleGUI;
import net.sf.latexdraw.instruments.TextSetter;
import net.sf.latexdraw.models.interfaces.shape.IGrid;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class TestHandGridStyle extends TestGridStyleGUI {
	@Override
	protected Injector createInjector() {
		return new ShapePropInjector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				super.configure();
				pencil = mock(Pencil.class);
				bindAsEagerSingleton(ShapeGridCustomiser.class);
				bindAsEagerSingleton(Hand.class);
				bindToInstance(MetaShapeCustomiser.class, mock(MetaShapeCustomiser.class));
				bindToInstance(TextSetter.class, mock(TextSetter.class));
				bindToInstance(Pencil.class, pencil);
			}
		};
	}

	@Override
	@Before
	public void setUp() {
		super.setUp();
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;


	@Test
	public void testPickcolourLabelsColourHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddGrid, selectionAddGrid, updateIns).execute();
		pickcolourLabels.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testPickLineColourHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddGrid, selectionAddGrid, updateIns).execute();
		pickcolourSubGrid.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testIncrementgridWidthHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddGrid, selectionAddGrid, updateIns), gridWidth,
			incrementgridWidth, Arrays.asList(
			() ->  ((IGrid) drawing.getSelection().getShapeAt(1)).getGridWidth(),
			() ->  ((IGrid) drawing.getSelection().getShapeAt(2)).getGridWidth()));
	}

	@Test
	public void testIncrementsubGridWidthHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddGrid, selectionAddGrid, updateIns), subGridWidth,
			incrementsubGridWidth, Arrays.asList(
			() ->  ((IGrid) drawing.getSelection().getShapeAt(1)).getSubGridWidth(),
			() ->  ((IGrid) drawing.getSelection().getShapeAt(2)).getSubGridWidth()));
	}

	@Test
	public void testIncrementgridDotsHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddGrid, selectionAddGrid, updateIns), gridDots,
			incrementgridDots, Arrays.asList(
			() ->  ((IGrid) drawing.getSelection().getShapeAt(1)).getGridDots(),
			() ->  ((IGrid) drawing.getSelection().getShapeAt(2)).getGridDots()));
	}

	@Test
	public void testIncrementsubGridDotsHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddGrid, selectionAddGrid, updateIns), subGridDots,
			incrementsubGridDots, Arrays.asList(
			() ->  ((IGrid) drawing.getSelection().getShapeAt(1)).getSubGridDots(),
			() ->  ((IGrid) drawing.getSelection().getShapeAt(2)).getSubGridDots()));
	}

	@Test
	public void testIncrementsubGridDivHand() {
		doTestSpinner(new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddGrid, selectionAddGrid, updateIns), subGridDiv,
			incrementsubGridDiv, Arrays.asList(
			() ->  ((IGrid) drawing.getSelection().getShapeAt(1)).getSubGridDiv(),
			() ->  ((IGrid) drawing.getSelection().getShapeAt(2)).getSubGridDiv()));
	}

	@Test
	public void testSelectlabelsYInvertedCBHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddGrid, selectionAddGrid, updateIns).execute();
		clicklabelsYInvertedCB.execute();
		waitFXEvents.execute();
	}

	@Test
	public void testSelectlabelsXInvertedCBHand() {
		new CompositeGUIVoidCommand(activateHand, selectionAddDot, selectionAddGrid, selectionAddGrid, updateIns).execute();
		clicklabelsXInvertedCB.execute();
		waitFXEvents.execute();
	}
}
