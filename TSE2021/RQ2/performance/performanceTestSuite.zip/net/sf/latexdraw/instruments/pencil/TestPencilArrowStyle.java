package net.sf.latexdraw.instruments.pencil;

import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.concurrent.TimeoutException;
import net.sf.latexdraw.instruments.CompositeGUIVoidCommand;
import net.sf.latexdraw.instruments.Hand;
import net.sf.latexdraw.instruments.MetaShapeCustomiser;
import net.sf.latexdraw.instruments.Pencil;
import net.sf.latexdraw.instruments.ShapeArrowCustomiser;
import net.sf.latexdraw.instruments.ShapePropInjector;
import net.sf.latexdraw.instruments.TestArrowStyleGUI;
import net.sf.latexdraw.instruments.TextSetter;
import net.sf.latexdraw.models.interfaces.shape.ArrowStyle;
import net.sf.latexdraw.models.interfaces.shape.IArrowableSingleShape;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class TestPencilArrowStyle extends TestArrowStyleGUI {
	long time;

	@Override
	protected Injector createInjector() {
		return new ShapePropInjector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				super.configure();
				hand = mock(Hand.class);
				bindAsEagerSingleton(ShapeArrowCustomiser.class);
				bindAsEagerSingleton(Pencil.class);
				bindToInstance(MetaShapeCustomiser.class, mock(MetaShapeCustomiser.class));
				bindToInstance(TextSetter.class, mock(TextSetter.class));
				bindToInstance(Hand.class, hand);
			}
		};
	}

	@Override
	@Before
	public void setUp() {
		super.setUp();
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}

	@Test
	public void testSelectLeftArrowStyleLEFTARROWPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.LEFT_ARROW);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleBARENDPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.BAR_END);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleBARINPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.BAR_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleCIRCLEENDPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.CIRCLE_END);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleCIRCLEINPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.CIRCLE_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleDISKENDPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.DISK_END);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleDISKINPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.DISK_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleLEFTDBLEARROWPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.LEFT_DBLE_ARROW);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleLEFTROUNDBRACKETPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.LEFT_ROUND_BRACKET);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleLEFTSQUAREBRACKETPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.LEFT_SQUARE_BRACKET);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleNONEPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.NONE);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleRIGHTARROWPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.RIGHT_ARROW);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleRIGHTDBLEARROWPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.RIGHT_DBLE_ARROW);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleRIGHTROUNDBRACKETPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.RIGHT_ROUND_BRACKET);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleRIGHTSQUAREBRACKETPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.RIGHT_SQUARE_BRACKET);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectLeftArrowStyleROUNDINPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowLeftCB.execute(ArrowStyle.ROUND_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleLEFTARROWPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.LEFT_ARROW);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleBARENDPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.BAR_END);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleBARINPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.BAR_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleCIRCLEENDPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.CIRCLE_END);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleCIRCLEINPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.CIRCLE_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleDISKENDPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.DISK_END);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleDISKINPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.DISK_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleLEFTDBLEARROWPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.LEFT_DBLE_ARROW);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleLEFTROUNDBRACKETPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.LEFT_ROUND_BRACKET);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleLEFTSQUAREBRACKETPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.LEFT_SQUARE_BRACKET);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleNONEPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.NONE);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleRIGHTARROWPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.RIGHT_ARROW);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleRIGHTDBLEARROWPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.RIGHT_DBLE_ARROW);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleRIGHTROUNDBRACKETPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.RIGHT_ROUND_BRACKET);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleRIGHTSQUAREBRACKETPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.RIGHT_SQUARE_BRACKET);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectRightArrowStyleROUNDINPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.ROUND_IN);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectArrowStyleArrowBarPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.LEFT_ARROW);
		selectArrowLeftCB.execute(ArrowStyle.BAR_END);
		waitFXEvents.execute();
	}

	@Test
	public void testSelectArrowStyleDiskRBracketPencil() {
		new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns).execute();
		selectArrowRightCB.execute(ArrowStyle.DISK_END);
		selectArrowLeftCB.execute(ArrowStyle.LEFT_ROUND_BRACKET);
		waitFXEvents.execute();
	}

	@Test
	public void testIncrementtbarsizeNumPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleRBrack), tbarsizeNum, incrementtbarsizeNum,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getTBarSizeNum()));
	}

	@Test
	public void testIncrementtbarsizeDimPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleRBrack), tbarsizeDim, incrementtbarsizeDim,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getTBarSizeDim()));
	}

	@Test
	public void testIncrementdotSizeNumPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleDot), dotSizeNum, incrementdotSizeNum,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getDotSizeNum()));
	}

	@Test
	public void testIncrementdotSizeDimPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleDot), dotSizeDim, incrementdotSizeDim,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getDotSizeDim()));
	}

	@Test
	public void testIncrementrbracketNumPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleRBrack), rbracketNum, incrementrbracketNum,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getRBracketNum()));
	}

	@Test
	public void testIncrementbracketNumPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleSBrack), bracketNum, incrementbracketNum,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getBracketNum()));
	}

	@Test
	public void testIncrementarrowLengthPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleArrow), arrowLength, incrementarrowLength,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getArrowLength()));
	}

	@Test
	public void testIncrementarrowInsetPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleArrow), arrowInset, incrementarrowInset,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getArrowInset()));
	}

	@Test
	public void testIncrementarrowSizeNumPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleArrow), arrowSizeNum, incrementarrowSizeNum,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getArrowSizeNum()));
	}

	@Test
	public void testIncrementarrowSizeDimPencil() {
		doTestSpinner(new CompositeGUIVoidCommand(activatePencil, pencilCreatesBezier, updateIns, selectArrowStyleArrow), arrowSizeDim, incrementarrowSizeDim,
			Collections.singletonList(() -> ((IArrowableSingleShape) pencil.createShapeInstance()).getArrowSizeDim()));
	}
}
