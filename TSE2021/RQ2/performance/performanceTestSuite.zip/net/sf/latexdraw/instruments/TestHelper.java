package net.sf.latexdraw.instruments;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.TimeoutException;
import javafx.application.HostServices;
import javafx.application.Platform;
import javafx.stage.Stage;
import net.sf.latexdraw.util.Injector;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class TestHelper extends TestLatexdrawGUI {
	Helper helper;
	HostServices services;

	@Override
	public String getFXMLPathFromLatexdraw() {
		return "/fxml/Help.fxml";
	}

	@Override
	protected Injector createInjector() {
		return new Injector() {
			@Override
			protected void configure() throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
				bindToInstance(HostServices.class, Mockito.mock(HostServices.class));
				bindAsEagerSingleton(Helper.class);
			}
		};
	}

	@Before
	public void setUp() {
		helper = injector.getInstance(Helper.class);
		services = injector.getInstance(HostServices.class);
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;

	@Test
	public void testClickAboutFrame() {
		clickOn("#helpMenu").clickOn("#aboutItem");
		waitFXEvents.execute();
		final Stage frame = helper.getAboutFrame();
		Platform.runLater(() -> helper.getAboutFrame().close());
		waitFXEvents.execute();
	}

	@Test
	public void testClickShortCutsFrame() {
		clickOn("#helpMenu").clickOn("#shortcutItem");
		waitFXEvents.execute();
		final Stage frame = helper.getShortcutsFrame();
		Platform.runLater(() -> helper.getShortcutsFrame().close());
		waitFXEvents.execute();
	}

	@Test
	public void testClickDonateItemFrame() {
		clickOn("#helpMenu").clickOn("#donateItem");
		waitFXEvents.execute();
	}

	@Test
	public void testClickManualItemFrame() {
		clickOn("#helpMenu").clickOn("#manuelItem");
		waitFXEvents.execute();
	}

	@Test
	public void testClickReportItemFrame() {
		clickOn("#helpMenu").clickOn("#reportBugItem");
		waitFXEvents.execute();
	}

	@Test
	public void testClickForumItemFrame() {
		clickOn("#helpMenu").clickOn("#forumItem");
		waitFXEvents.execute();
	}
}
