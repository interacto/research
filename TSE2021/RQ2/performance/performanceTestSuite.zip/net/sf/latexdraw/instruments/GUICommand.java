package net.sf.latexdraw.instruments;

public interface GUICommand<T> {
	void execute(T param);
}
