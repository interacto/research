package net.sf.latexdraw.instruments;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.TimeoutException;
import javafx.application.Platform;
import javafx.stage.DirectoryChooser;
import net.sf.latexdraw.instruments.robot.FxRobotListSelection;
import net.sf.latexdraw.instruments.robot.FxRobotSpinner;
import net.sf.latexdraw.util.Injector;
import net.sf.latexdraw.util.Preference;
import net.sf.latexdraw.view.MagneticGrid;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import static org.junit.Assert.fail;

public class TestPreferencesSetter extends TestLatexdrawGUI implements FxRobotListSelection, FxRobotSpinner {
	PreferencesSetter setter;

	@Override
	protected String getFXMLPathFromLatexdraw() {
		return "/fxml/Preferences.fxml";
	}

	@Override
	protected Injector createInjector() {
		return new ShapePropInjector() {
			@Override
			protected void configure() throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
				super.configure();
				bindAsEagerSingleton(PreferencesSetter.class);
				bindToInstance(FileLoaderSaver.class, Mockito.mock(FileLoaderSaver.class));
				bindToInstance(MagneticGrid.class, Mockito.mock(MagneticGrid.class));
				bindToInstance(Exporter.class, Mockito.mock(Exporter.class));
			}
		};
	}

	@Before
	public void setUp() {
		try {
			final Field field = Preference.class.getDeclaredField("preferences");
			field.setAccessible(true);
			field.set(null, null);
		}catch(final NoSuchFieldException | IllegalAccessException ex) {
			fail(ex.getMessage());
		}
		setter = (PreferencesSetter) injectorFactory.call(PreferencesSetter.class);
		setter.setActivated(true);
		time = System.currentTimeMillis();
	}

	@Override
	@After
	public void tearDown() throws TimeoutException {
		System.out.println("[EXPERIMENT TIME] " + (System.currentTimeMillis() - time));
		super.tearDown();
	}
	long time;


	@Test
	public void testReadWriteMagneticGrid() {
		Platform.runLater(() -> setter.readXMLPreferences());
		waitFXEvents.execute();
		clickOn(setter.magneticCB);
		waitFXEvents.execute();
	}

	@Test
	public void testReadWriteCheckNewVersion() {
		Platform.runLater(() -> setter.readXMLPreferences());
		waitFXEvents.execute();
		clickOn(setter.checkNewVersion);
		waitFXEvents.execute();
	}

	@Test
	public void testChangeMagneticGrid() {
		Platform.runLater(() -> setter.readXMLPreferences());
		waitFXEvents.execute();
		selectNextComboBoxItem(setter.styleList);
		waitFXEvents.execute();
	}

	@Test
	public void testGidGap() {
		Platform.runLater(() -> setter.readXMLPreferences());
		waitFXEvents.execute();
		incrementSpinner(setter.persoGridGapField);
		waitFXEvents.execute();
	}

	@Test
	public void testClickChooseLoadFolder() throws NoSuchFieldException, IllegalAccessException {
		final DirectoryChooser chooser = Mockito.mock(DirectoryChooser.class);
			Mockito.when(chooser.showDialog(Mockito.any())).thenReturn(new File("foo"));
		final Field field = PreferencesSetter.class.getDeclaredField("fileChooser");
		field.setAccessible(true);
		field.set(setter, chooser);
		clickOn("#buttonOpen");
		waitFXEvents.execute();
	}

	@Test
	public void testClickChooseExportFolder() throws NoSuchFieldException, IllegalAccessException {
		final DirectoryChooser chooser = Mockito.mock(DirectoryChooser.class);
			Mockito.when(chooser.showDialog(Mockito.any())).thenReturn(new File("bar"));
		final Field field = PreferencesSetter.class.getDeclaredField("fileChooser");
		field.setAccessible(true);
		field.set(setter, chooser);
		clickOn("#buttonExport");
		waitFXEvents.execute();
	}
}
